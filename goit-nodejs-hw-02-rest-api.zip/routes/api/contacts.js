const express = require('express');
// const createError = require('http-errors');
const { BadRequest, NotFound } = require('http-errors');
const Joi = require('joi');

const contactSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  phone: Joi.string().required(),
});

const {
  listContacts,
  getContactById,
  addContact,
  removeContact,
  updateContact,
} = require('../../models/contacts');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const contacts = await listContacts();
    res.json({
      status: 'success',
      code: 200,
      data: {
        contacts,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:contactId', async (req, res, next) => {
  try {
    const { contactId } = req.params;
    const contact = await getContactById(contactId);

    if (!contact) {
      throw new NotFound(`Contact with id = ${contactId} not found`);
      // throw createError(404, `Contact with id = ${contactId} not found`);
      // const error = new Error(`Contact with id = ${contactId} not found`); // создаем error
      // error.status = 404; // присваиваем статус error
      // throw error; // генерирует исключение error и передает управление в cath
    }
    res.json({
      status: 'success',
      code: 200,
      data: { contact },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const { name, email, phone } = req.body;
    const { error } = contactSchema.validate(req.body);

    if (error) {
      throw BadRequest(`missing ${error.message} field`);
    }

    const contact = await addContact({ name, email, phone });
    res.status(201).json({
      status: 'success',
      code: 201,
      data: { contact },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/:contactId', async (req, res, next) => {
  try {
    const { contactId } = req.params;
    const contact = await removeContact(contactId);
    if (!contact) {
      throw new NotFound(`Contact with id = ${contactId} not found`);
    }
    res.json({
      status: 'success',
      code: 200,
      message: 'contact deleted',
      data: {
        contact,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.put('/:contactId', async (req, res, next) => {
  try {
    const { error } = contactSchema.validate(req.body);
    if (error) {
      throw BadRequest(`missing ${error.message} field`);
    }

    const { contactId } = req.params;
    const { name, email, phone } = req.body;

    const contact = await updateContact(contactId, { name, email, phone });
    console.log(contact);
    if (!contact) {
      throw new NotFound(`Contact with id = ${contactId} not found`);
    }

    res.json({
      status: 'success',
      code: 200,
      data: {
        contact,
      },
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
